package analisadorlexico.main;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.filechooser.FileNameExtensionFilter;

import analisadorlexico.exception.RbLexicalException;
import analisadorlexico.lexico.RbScanner;
import analisadorlexico.lexico.Token;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class MainPane {

	private JFrame frame;
	String caminho;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainPane window = new MainPane();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainPane() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 600, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JScrollPane scrollPaneInput = new JScrollPane();
		
		JTextPane inputsTP = new JTextPane();
		scrollPaneInput.setViewportView(inputsTP);
		inputsTP.setEditable(false);
		
		JScrollPane scrollPaneToken = new JScrollPane();
		
		JTextPane tokensTP = new JTextPane();
		scrollPaneToken.setViewportView(tokensTP);
		tokensTP.setEditable(false);
		
		JButton btnUpload = new JButton("Upload");
		btnUpload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser procurar = new JFileChooser();
				procurar.setFileSelectionMode(JFileChooser.FILES_ONLY);
				FileNameExtensionFilter filtro = new FileNameExtensionFilter("Apenas .rb", "rb");
				procurar.setAcceptAllFileFilterUsed(false);
				procurar.addChoosableFileFilter(filtro);
				int respostaDoJFileChooser = procurar.showOpenDialog(null);
				if(respostaDoJFileChooser == JFileChooser.APPROVE_OPTION) {
					File arquivo = procurar.getSelectedFile();
					caminho = arquivo.getAbsolutePath();
					try {
						String Conteudo = new String(Files.readAllBytes(Paths.get(caminho)),StandardCharsets.UTF_8);
						inputsTP.setText(Conteudo);
						tokensTP.setText(null);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				else {
					JOptionPane.showMessageDialog(btnUpload, "Nenhum arquivo selecionado");
				}
			}
		});
		
		JButton btnAnalisar = new JButton("Analisar");
		btnAnalisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(inputsTP.getText().isEmpty()) {
					JOptionPane.showMessageDialog(btnAnalisar, "Por favor fa�a o upload de um arquivo em Ruby para ser analisado!");
				}
				else {
					try {
						RbScanner sc = new RbScanner(caminho);
						Token token = null;
						String tokens = "";
						do {
							token = sc.nextToken();
							if (token != null) {
								tokens += token.toString();
							}
						} while (token != null);
						tokensTP.setText(tokens);
					}
					catch(RbLexicalException ex) {
						System.out.println("ERRO Lexico " + ex.getMessage());
					}
					catch(Exception ex) {
						System.out.println(ex.getMessage());
					}
				}
			}
		});
		
		JButton btnLimpar = new JButton("Limpar");
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (inputsTP.getText().isEmpty() && tokensTP.getText().isEmpty()) {
					JOptionPane.showMessageDialog(btnLimpar, "N�o h� nada para ser limpo");
				}
				else {
					inputsTP.setText(null);
					tokensTP.setText(null);
				}
			}
		});
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(10)
					.addComponent(scrollPaneInput, GroupLayout.DEFAULT_SIZE, 220, Short.MAX_VALUE)
					.addGap(10)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(btnUpload, GroupLayout.PREFERRED_SIZE, 104, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnAnalisar, GroupLayout.PREFERRED_SIZE, 104, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnLimpar, GroupLayout.PREFERRED_SIZE, 104, GroupLayout.PREFERRED_SIZE))
					.addGap(10)
					.addComponent(scrollPaneToken, GroupLayout.DEFAULT_SIZE, 220, Short.MAX_VALUE)
					.addGap(10))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(11)
					.addComponent(scrollPaneInput, GroupLayout.DEFAULT_SIZE, 389, Short.MAX_VALUE)
					.addGap(11))
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(128)
					.addComponent(btnUpload, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)
					.addGap(11)
					.addComponent(btnAnalisar, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)
					.addGap(11)
					.addComponent(btnLimpar, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE))
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(11)
					.addComponent(scrollPaneToken, GroupLayout.DEFAULT_SIZE, 389, Short.MAX_VALUE)
					.addGap(11))
		);
		frame.getContentPane().setLayout(groupLayout);
		
	}
}
