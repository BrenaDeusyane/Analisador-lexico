package analisadorlexico.main;

import analisadorlexico.exception.RbLexicalException;
import analisadorlexico.lexico.RbScanner;
import analisadorlexico.lexico.Token;

public class Debugggg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			RbScanner sc = new RbScanner("C:\\Users\\�talo C�sar\\Documents\\Analisador l�xico\\Testes\\teste7.rb");
			Token token = null;
			String tokens = "";
			do {
				token = sc.nextToken();
				if (token != null) {
					tokens += token.toString();
				}
			} while (token != null);
			System.out.println(tokens);
		}
		catch(RbLexicalException ex) {
			System.out.println("ERRO Lexico " + ex.getMessage());
		}
		catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}

}
