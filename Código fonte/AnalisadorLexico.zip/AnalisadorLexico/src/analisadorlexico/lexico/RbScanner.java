package analisadorlexico.lexico;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

import analisadorlexico.exception.RbLexicalException;

public class RbScanner {

	private char[] content;
	private int estado;
	private int pos;
	
	public RbScanner(String filename) {
		try {
			String txtConteudo = new String(Files.readAllBytes(Paths.get(filename)),StandardCharsets.UTF_8);
			content = txtConteudo.toCharArray();
			pos = 0;
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public Token nextToken() {
		char currentChar;
		Token token;
		String term = "";
		if (isEOF()) {
			return null;
		}
		estado = 0;
		while (true) {
			currentChar = nextChar();
			
			switch(estado) {
			case 0:
				if (isSpace(currentChar)) {
					estado = 0;
					if (isEOF()) {
						return null;
					}
				}
				else if (currentChar == '@' || currentChar == '$') {
					estado = 1;
					term += currentChar;
				}
				else if (isChar(currentChar)) {
					estado = 2;
					term += currentChar;
				}
				else if (isDigit(currentChar)) {
					estado = 4;
					term += currentChar;
				}
				else if (currentChar == '.') {
					estado = 6;
					term += currentChar;
				}
				else if (isOperator(currentChar)) {
					estado = 7;
					term += currentChar;
				}
				else if (isStructure(currentChar)) {
					estado = 9;
					term += currentChar;
				}
				else {
					throw new RbLexicalException("S�mbolo n�o reconhecido");
				}
				break;
			case 1:
				if (currentChar == '@' && term.length() == 1) {
					estado = 1;
					term += currentChar;
				}
				else if (isChar(currentChar)) {
					estado = 2;
					term += currentChar;
				}
				else {
					throw new RbLexicalException("Vari�vel n�o reconhecido");
				}
				break;
			case 2:
				if (isChar(currentChar) || isDigit(currentChar)) {
					estado = 2;
					term += currentChar;
				}
				else if (isSpace(currentChar) || isOperator(currentChar) || isStructure(currentChar)){
					estado = 3;
					back();
				}
				else {
					throw new RbLexicalException("Identificador n�o reconhecido");
				}
				break;
			case 3:
				token = new Token();
				if (isReserved(term)) {
					token.setType(Token.TK_RESERVEDWORD);
				}
				else {
					token.setType(Token.TK_IDENTIFIER);
				}
				token.setText(term);
				back();
				return token;
			case 4:
				if (isDigit(currentChar)) {
					estado = 4;
					term += currentChar;
				}
				else if (!isChar(currentChar)) {
					estado = 5;
					back();
				}
				else {
					throw new RbLexicalException("N�mero n�o reconhecido");
				}
				break;
			case 5:
				token = new Token();
				token.setType(Token.TK_NUMBER);
				token.setText(term);
				back();
				return token;
			case 6:
				if (isChar(currentChar)) {
					estado = 6;
					term += currentChar;
				}
				else if (isOperator(currentChar)){
					estado = 7;
					term += currentChar;
				}
				break;
			case 7:
				if (isOperator(currentChar)) {
					estado = 7;
					term += currentChar;
				}
				else {
					estado = 8;
					back();
				}
				break;
			case 8:
				if (isOperator(term)) {
					token = new Token();
					token.setType(Token.TK_OPERATOR);
					token.setText(term);
					back();
					return token;
				}
				else {
					System.out.println(term);
					throw new RbLexicalException("Operador n�o reconhecido");
				}
			case 9:
				token = new Token();
				token.setType(Token.TK_STRUCTURAL);
				token.setText(term);
				back();
				return token;
			}
		}
	}
	
	private boolean isDigit (char c) {
		return c >= '0' && c <= '9';
	}
	
	private boolean isChar (char c) {
		return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
	}
	
	private boolean isOperator (char c) {
		return c == '+' || c == '-' || c == '*' || c == '/' || c == '%' || c == '=' || c == '>' || c == '<' || c == '&' || c == '|' || c == '!' || c == '^' || c == '~' || c == '?' || c == ':' || c == '.';
	}
	
	private boolean isOperator (String s) {
		return s.intern() == "+" || s.intern() == "-" || s.intern() == "*" || s.intern() == "/" || s.intern() == "%" || s.intern() == "**" || s.intern() == "=" || s.intern() == "==" || s.intern() == "!=" || s.intern() == ">" || s.intern() == "<" || s.intern() == ">=" || s.intern() == "<=" || s.intern() == "and" || s.intern() == "&&" || s.intern() == "or" || s.intern() == "||" || s.intern() == "not" || s.intern() == "&" || s.intern() == "!" || s.intern() == "^" || s.intern() == "~" || s.intern() == ">>" || s.intern() == "<<" || s.intern() == "?:" || s.intern() == ".." || s.intern() == "..." || s.intern() == "||=" || s.intern() == "<=>" || s.intern() == "===" || s.intern() == ".eql?" || s.intern() == ".equal?";
	}
	
	private boolean isSpace (char c) {
		return c == ' ' || c == '\t' || c == '\n' || c == '\r';
	}
	
	private boolean isReserved (String s) {
		return s.intern() == "alias" || s.intern() == "and" || s.intern() == "BEGIN" || s.intern() == "begin" || s.intern() == "break" || s.intern() == "case" || s.intern() == "class" || s.intern() == "def" || s.intern() == "defined" || s.intern() == "do" || s.intern() == "else" || s.intern() == "elsif" || s.intern() == "END" || s.intern() == "end" || s.intern() == "ensure" || s.intern() == "false" || s.intern() == "for" || s.intern() == "if" || s.intern() == "in" || s.intern() == "module" || s.intern() == "next" || s.intern() == "nil" || s.intern() == "not" || s.intern() == "or" || s.intern() == "print" || s.intern() == "printf" || s.intern() == "puts" || s.intern() == "redo" || s.intern() == "rescue" || s.intern() == "retry" || s.intern() == "return" || s.intern() == "self" || s.intern() == "super" || s.intern() == "then" || s.intern() == "true" || s.intern() == "undef" || s.intern() == "unless" || s.intern() == "until" || s.intern() == "when" || s.intern() == "while" || s.intern() == "yield";
	}
	
	private boolean isStructure (char c) {
		return c == '\"' || c == '\'' || c == '(' || c == ')' || c == '[' || c == ']';
	}
	
	private char nextChar() {
		if (!isEOF()) {
			return content[pos++];
		}
		return '\r';
	}
	
	private boolean isEOF() {
		return pos == content.length;
	}
	
	private void back() {
		if (!isEOF()) {
			pos--;
		}
	}
}
