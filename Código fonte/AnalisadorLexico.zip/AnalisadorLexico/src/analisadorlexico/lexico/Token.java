package analisadorlexico.lexico;

public class Token {
	public static final String TK_IDENTIFIER = "Identificador";
	public static final String TK_NUMBER = "N�mero";
	public static final String TK_OPERATOR = "Operador";
	public static final String TK_RESERVEDWORD = "Palavra reservada";
	public static final String TK_STRUCTURAL = "Estrutural";
	
	private String type;
	private String text;
	
	public Token(String type, String text) {
		super();
		this.type = type;
		this.text = text;
	}
	
	public Token() {
		super();
	}
	
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getText() {
		return text;
	}
	
	public void setText(String text) {
		this.text = text;
	}
	
	@Override
	public String toString() {
		return "[tipo: " + type + ", conteudo: '" + text + "']\n";
	}
}
