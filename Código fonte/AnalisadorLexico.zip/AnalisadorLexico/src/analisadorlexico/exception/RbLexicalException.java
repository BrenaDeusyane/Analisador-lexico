package analisadorlexico.exception;

public class RbLexicalException extends RuntimeException {
	public RbLexicalException(String msg) {
		super(msg);
	}
}
